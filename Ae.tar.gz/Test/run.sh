#!/usr/bin/env bash
# =============================================================================
#  Ae 回归测试（Linux / macOS）—— 与 run.ps1 对应
# -----------------------------------------------------------------------------
#  正向用例：cases/<名字>.ae  必须编译并成功运行，stdout 与 .out 完全一致
#  失败用例：errors/<名字>.ae 必须失败（编译期或运行期都行），stderr 含 .err 文本
#
#  用法：
#      ./run.sh                # 全部
#      ./run.sh -Filter p13    # 只跑名字含 p13 的
#      AE_LIB_PATH=... ./run.sh
# =============================================================================
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APT="$HERE/../Apt"
AEC="$APT/aec"
AE="$APT/ae"
FILTER=""

for a in "$@"; do
  case "$a" in
    -Filter)    ;;
    -Filter=*)  FILTER="${a#-Filter=}" ;;
    *)          [[ -z "$FILTER" ]] && FILTER="$a" ;;
  esac
done
if [[ "${1:-}" == "-Filter" ]]; then FILTER="${2:-}"; fi

[[ -x "$AEC" ]] || { echo "找不到 $AEC，先跑 ../build.sh"; exit 2; }
[[ -x "$AE"  ]] || { echo "找不到 $AE，先跑 ../build.sh";  exit 2; }

pass=0; fail=0; failed=()

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

norm() { sed -e 's/\r$//' "$1"; }

run_case() {   # $1 = 无扩展名的用例文件路径
  local base="$1" name; name="$(basename "$base")"
  local dir; dir="$(dirname "$base")"
  "$AEC" "$base.ae" -o "$TMP/$name.aeo" -q >"$TMP/$name.cerr" 2>&1
  if [[ $? -ne 0 ]]; then
    echo "  ✗ $name：编译失败"; sed 's/^/      /' "$TMP/$name.cerr" | head -5
    return 1
  fi
  (cd "$TMP" && "$AE" "$TMP/$name.aeo" >"$TMP/$name.out" 2>"$TMP/$name.eout")
  local rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "  ✗ $name：运行失败（退出码 $rc）"; sed 's/^/      /' "$TMP/$name.eout" | head -5
    return 1
  fi
  if ! diff -q <(norm "$dir/$name.out") <(norm "$TMP/$name.out") >/dev/null; then
    echo "  ✗ $name：输出不一致"
    diff <(norm "$dir/$name.out") <(norm "$TMP/$name.out") | head -12 | sed 's/^/      /'
    return 1
  fi
  return 0
}

run_error() {
  local base="$1" name; name="$(basename "$base")"
  local dir; dir="$(dirname "$base")"
  local err; err="$(cat "$dir/$name.err")"
  "$AEC" "$base.ae" -o "$TMP/$name.aeo" -q >"$TMP/$name.log" 2>&1
  local compiled=$?
  if [[ $compiled -eq 0 ]]; then
    (cd "$TMP" && "$AE" "$TMP/$name.aeo" >>"$TMP/$name.log" 2>&1)
    local rc=$?
    [[ $rc -eq 0 ]] && { echo "  ✗ $name：期望失败但成功了"; return 1; }
  fi
  if ! grep -qF -- "$err" "$TMP/$name.log"; then
    echo "  ✗ $name：stderr 里没有 “$err”"; sed 's/^/      /' "$TMP/$name.log" | head -5
    return 1
  fi
  return 0
}

echo "── 正向用例 cases/ ──"
for f in "$HERE"/cases/*.ae; do
  n="$(basename "$f" .ae)"
  [[ -n "$FILTER" && "$n" != *"$FILTER"* ]] && continue
  [[ -f "$HERE/cases/$n.out" ]] || continue
  if run_case "$HERE/cases/$n"; then echo "  ✓ $n"; pass=$((pass+1)); else fail=$((fail+1)); failed+=("cases/$n"); fi
done

echo "── 失败用例 errors/ ──"
for f in "$HERE"/errors/*.ae; do
  n="$(basename "$f" .ae)"
  [[ -n "$FILTER" && "$n" != *"$FILTER"* ]] && continue
  [[ -f "$HERE/errors/$n.err" ]] || continue
  if run_error "$HERE/errors/$n"; then echo "  ✓ $n"; pass=$((pass+1)); else fail=$((fail+1)); failed+=("errors/$n"); fi
done

echo
echo "通过 $pass，失败 $fail"
[[ $fail -eq 0 ]] || { printf '失败的用例：%s\n' "${failed[*]}"; exit 1; }
