// geo.m —— 检查 .m 模块能不能用上语言/库的新特性（imp 库、纯数据加工、闭包、回调）
//   结论要能跑通：模块里可以 imp 库、做数据加工、返回闭包、调用脚本传进来的闭包。
imp io
imp path

// ① 模块里用库函数加工路径
func makeStarName(dir, name) {
    return path.join(dir, name + ".star")
}

// ② 纯数据版：直接返回顶点表（模块只做数据加工）
func rectPoints(x, y, w2, h2) {
    return {x, y, x + w2, y, x + w2, y + h2, x, y + h2}
}

func areaOf(r) {
    if (len(r) < 8) return 0
    return (r[3] - r[1]) * (r[6] - r[2])
}

// ③ 模块导出的闭包工厂（引用捕获）
func counter(start) {
    local n = start
    return func() { n += 1  return n }
}

// ④ 模块调用脚本传进来的闭包
func each(t, cb) {
    for i, v in t { cb(i, v) }
    return len(t)
}

// ⑤ 模块里读文件（库也可以在模块里用）
func firstLine(file) {
    local t = io.readFile(file)
    if (t == null) return null
    return t
}
