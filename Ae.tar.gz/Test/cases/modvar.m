// 模块顶层变量示例（放在 cases/ 下，随用例一起被找到）
version = "1.2.0"
maxRetries = 3
timeoutMs = 2500
_debug = true
local secret = "internal"

func describe() {
    return "v" + version + " retries=" + str(maxRetries) + " secret=" + secret
}
