// 默认参数用例的配套模块
func encode(v, indent = 2, pretty = true) {
    return "v=" + str(v) + " i=" + str(indent) + " p=" + str(pretty)
}
