// 变参用例的配套模块
func join(sep, parts...) {
    local s = ""
    for i, p in parts { if (i > 1) { s = s + sep } s = s + str(p) }
    return s
}
