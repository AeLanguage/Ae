pub = 1
_priv = 2
local hidden = 3
func get() { return pub + _priv + hidden }
